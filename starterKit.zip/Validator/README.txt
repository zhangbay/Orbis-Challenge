---DISCLAIMER---
This validator mimics the way we will be grading your submission.
In NO WAY does it give any indication whether or not your AI is behaving
"normally" or how it will do in the tournament. It only validates
whether or not we can unzip your submission and run it. Running properly in
the validator DOES NOT indicate that your AI will run properly during the 
tournament i.e. timing out, throwing errors, etc.
---DISCLAIMER---

Instructions for running the validator:

1) Zip up your submission and rename it to "botplayer.zip"
2) Place the zipped file in the "Submission" folder. Make sure there are no other files in this folder.
2) Run the validate script and follow the on-screen prompts.

Note: You cannot view the game during validation. You can however review
the results of the validation using the .json file in the "Results" folder.