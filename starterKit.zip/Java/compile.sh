javac -classpath ./"Java Library"/JavaClient.jar:./botplayer:./"Java Library"/* ./botplayer/PlayerAI.java -verbose
