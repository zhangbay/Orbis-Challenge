JSON_SETTINGS_PATH = "Resources/settings.json"
PLAYER_AI_PATH = "botplayer" 
